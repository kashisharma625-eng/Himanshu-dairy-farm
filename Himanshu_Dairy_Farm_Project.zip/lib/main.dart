import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as p;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await DairyDb.instance.database;
  runApp(const DairyApp());
}

class DairyDb {
  DairyDb._();
  static final instance = DairyDb._();
  Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    final path = p.join(await getDatabasesPath(), 'himanshu_dairy.db');
    _db = await openDatabase(path, version: 1, onCreate: (db, version) async {
      await db.execute('''CREATE TABLE animals(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL, tag TEXT, weight REAL, notes TEXT)''');
      await db.execute('''CREATE TABLE milk(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        animal_id INTEGER, date TEXT, session TEXT, litres REAL)''');
      await db.execute('''CREATE TABLE feed(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        animal_id INTEGER, date TEXT, item TEXT, kg REAL)''');
      await db.execute('''CREATE TABLE expenses(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        date TEXT, title TEXT, amount REAL)''');
    });
    return _db!;
  }

  Future<int> addAnimal(String name, String tag, double weight) async =>
      (await database).insert('animals', {'name': name, 'tag': tag, 'weight': weight});
  Future<List<Map<String, Object?>>> animals() async =>
      (await database).query('animals', orderBy: 'id DESC');
  Future<int> addMilk(int animalId, String session, double litres) async =>
      (await database).insert('milk', {
        'animal_id': animalId, 'date': DateTime.now().toIso8601String().substring(0, 10),
        'session': session, 'litres': litres
      });
  Future<int> addFeed(int animalId, String item, double kg) async =>
      (await database).insert('feed', {
        'animal_id': animalId, 'date': DateTime.now().toIso8601String().substring(0, 10),
        'item': item, 'kg': kg
      });
  Future<List<Map<String, Object?>>> milkToday() async {
    final d = DateTime.now().toIso8601String().substring(0, 10);
    return (await database).rawQuery(
      'SELECT milk.*, animals.name AS animal_name FROM milk LEFT JOIN animals ON animals.id=milk.animal_id WHERE date=? ORDER BY milk.id DESC', [d]);
  }
  Future<double> todayMilkTotal() async {
    final d = DateTime.now().toIso8601String().substring(0, 10);
    final r = await (await database).rawQuery('SELECT SUM(litres) AS total FROM milk WHERE date=?', [d]);
    return (r.first['total'] as num?)?.toDouble() ?? 0;
  }
}

class DairyApp extends StatelessWidget {
  const DairyApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Himanshu Dairy Farm',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF167A55), primary: const Color(0xFF167A55), secondary: const Color(0xFFF2A93B), surface: const Color(0xFFF7FAF8)),
      scaffoldBackgroundColor: const Color(0xFFF4F8F5),
      appBarTheme: const AppBarTheme(backgroundColor: Color(0xFF126747), foregroundColor: Colors.white, elevation: 0, titleTextStyle: TextStyle(fontSize: 19, fontWeight: FontWeight.w800, color: Colors.white)),
      cardTheme: CardThemeData(color: Colors.white, elevation: 1.5, shadowColor: Color(0x14126447), margin: EdgeInsets.zero, shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(20)))),
      inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: Color(0xFFF5F8F6), contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 15), border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(14)), borderSide: BorderSide.none), enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(14)), borderSide: BorderSide(color: Color(0xFFE2EBE5))), focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(14)), borderSide: BorderSide(color: Color(0xFF167A55), width: 1.5))),
      filledButtonTheme: FilledButtonThemeData(style: FilledButton.styleFrom(backgroundColor: const Color(0xFF167A55), foregroundColor: Colors.white, minimumSize: const Size.fromHeight(50), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)), textStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15))),
      navigationBarTheme: const NavigationBarThemeData(backgroundColor: Colors.white, indicatorColor: Color(0xFFDDF2E6), labelTextStyle: WidgetStatePropertyAll(TextStyle(fontSize: 11, fontWeight: FontWeight.w600))),
    ),
    home: const HomePage(),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  Future<void> refresh() async { if (mounted) setState(() {}); }

  @override
  Widget build(BuildContext context) {
    final pages = [
      Dashboard(onRefresh: refresh),
      AnimalPage(onRefresh: refresh),
      MilkPage(onRefresh: refresh),
      FeedPage(onRefresh: refresh),
      const RationPage(),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Text('Himanshu Dairy Farm'),
        leading: const Padding(
          padding: EdgeInsets.only(left: 14),
          child: CircleAvatar(backgroundColor: Color(0x33FFFFFF), child: Icon(Icons.agriculture_rounded, color: Colors.white)),
        ),
      ),
      body: SafeArea(child: pages[tab]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), label: 'होम'),
          NavigationDestination(icon: Icon(Icons.pets), label: 'भैंस'),
          NavigationDestination(icon: Icon(Icons.water_drop), label: 'दूध'),
          NavigationDestination(icon: Icon(Icons.grass), label: 'खुराक'),
          NavigationDestination(icon: Icon(Icons.calculate), label: 'सलाह'),
        ],
      ),
    );
  }
}

class Dashboard extends StatelessWidget {
  final VoidCallback onRefresh;
  const Dashboard({super.key, required this.onRefresh});

  @override
  Widget build(BuildContext context) => FutureBuilder(
    future: Future.wait([DairyDb.instance.animals(), DairyDb.instance.todayMilkTotal()]),
    builder: (context, snap) {
      if (!snap.hasData) return const Center(child: CircularProgressIndicator());
      final animals = snap.data![0] as List<Map<String, Object?>>;
      final litres = snap.data![1] as double;
      return ListView(padding: const EdgeInsets.fromLTRB(16, 18, 16, 24), children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFF126747), Color(0xFF23966A)], begin: Alignment.topLeft, end: Alignment.bottomRight),
            borderRadius: BorderRadius.circular(24),
            boxShadow: const [BoxShadow(color: Color(0x26126447), blurRadius: 18, offset: Offset(0, 8))],
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              const Expanded(child: Text('नमस्ते! आपका डेयरी डैशबोर्ड', style: TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w800))),
              Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: Colors.white.withValues(alpha: .16), borderRadius: BorderRadius.circular(15)), child: const Icon(Icons.wb_sunny_rounded, color: Colors.white)),
            ]),
            const SizedBox(height: 22),
            const Text('आज का कुल दूध', style: TextStyle(color: Color(0xFFD9F2E5), fontSize: 13, fontWeight: FontWeight.w600)),
            const SizedBox(height: 3),
            Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
              Text(litres.toStringAsFixed(1), style: const TextStyle(color: Colors.white, fontSize: 38, height: 1.1, fontWeight: FontWeight.w900)),
              const Padding(padding: EdgeInsets.only(left: 7, bottom: 5), child: Text('लीटर', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w700))),
            ]),
            const SizedBox(height: 8),
            const Text('सुबह और शाम की एंट्री जोड़ते रहें', style: TextStyle(color: Color(0xFFD9F2E5), fontSize: 12)),
          ]),
        ),
        const SizedBox(height: 16),
        Row(children: [
          Expanded(child: _summaryCard(Icons.pets_rounded, 'कुल पशु', '${animals.length}', const Color(0xFFE4F3EA), const Color(0xFF167A55))),
          const SizedBox(width: 12),
          Expanded(child: _summaryCard(Icons.water_drop_rounded, 'आज का दूध', '${litres.toStringAsFixed(1)} L', const Color(0xFFE6F1FC), const Color(0xFF3478B8))),
        ]),
        const SizedBox(height: 22),
        const Text('जल्दी शुरू करें', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: Color(0xFF183B2B))),
        const SizedBox(height: 10),
        _guideTile(Icons.pets_rounded, 'पशु जोड़ें', 'नाम, टैग और वजन का रिकॉर्ड रखें', const Color(0xFF167A55)),
        const SizedBox(height: 9),
        _guideTile(Icons.water_drop_rounded, 'दूध दर्ज करें', 'सुबह और शाम का दूध लिखें', const Color(0xFF3478B8)),
        const SizedBox(height: 9),
        _guideTile(Icons.grass_rounded, 'खुराक दर्ज करें', 'रोज दिए गए चारे की मात्रा सेव करें', const Color(0xFFB47A19)),
        const SizedBox(height: 16),
        Card(child: Padding(padding: const EdgeInsets.all(15), child: Row(children: [
          const Icon(Icons.info_outline_rounded, color: Color(0xFF167A55)),
          const SizedBox(width: 10),
          const Expanded(child: Text('अपना रिकॉर्ड नियमित अपडेट करें, ताकि डेयरी का हिसाब सही बना रहे।', style: TextStyle(fontSize: 12, height: 1.4))),
          IconButton(onPressed: onRefresh, icon: const Icon(Icons.refresh_rounded, color: Color(0xFF167A55))),
        ]))),
      ]);
    },
  );

  static Widget _summaryCard(IconData icon, String label, String value, Color bg, Color fg) =>
    Card(child: Padding(padding: const EdgeInsets.all(15), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Container(padding: const EdgeInsets.all(9), decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(12)), child: Icon(icon, color: fg, size: 21)),
      const SizedBox(height: 13),
      Text(value, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: Color(0xFF183B2B))),
      Text(label, style: const TextStyle(fontSize: 12, color: Color(0xFF718078), fontWeight: FontWeight.w600)),
    ])));

  static Widget _guideTile(IconData icon, String title, String subtitle, Color color) =>
    Card(child: ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
      leading: Container(width: 43, height: 43, decoration: BoxDecoration(color: color.withValues(alpha: .10), borderRadius: BorderRadius.circular(13)), child: Icon(icon, color: color)),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
      subtitle: Text(subtitle, style: const TextStyle(fontSize: 12)),
      trailing: const Icon(Icons.chevron_right_rounded, color: Color(0xFF9AA9A0)),
    ));
}

class AnimalPage extends StatefulWidget {
  final VoidCallback onRefresh;
  const AnimalPage({super.key, required this.onRefresh});
  @override
  State<AnimalPage> createState() => _AnimalPageState();
}
class _AnimalPageState extends State<AnimalPage> {
  final name = TextEditingController(), tag = TextEditingController(), weight = TextEditingController();
  Future<void> add() async {
    final w = double.tryParse(weight.text);
    if (name.text.trim().isEmpty || w == null) return;
    await DairyDb.instance.addAnimal(name.text.trim(), tag.text.trim(), w);
    name.clear(); tag.clear(); weight.clear(); setState(() {}); widget.onRefresh();
  }
  @override
  Widget build(BuildContext context) => FutureBuilder(
    future: DairyDb.instance.animals(),
    builder: (context, snap) => ListView(padding: const EdgeInsets.all(16), children: [
      _pageHeading('पशुओं का रिकॉर्ड', 'हर भैंस की जानकारी यहाँ सुरक्षित रखें', Icons.pets_rounded),
      TextField(controller: name, decoration: const InputDecoration(labelText: 'भैंस का नाम')),
      TextField(controller: tag, decoration: const InputDecoration(labelText: 'पहचान / टैग नंबर')),
      TextField(controller: weight, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'वजन (किलो)')),
      FilledButton(onPressed: add, child: const Text('भैंस जोड़ें')),
      const Divider(),
      if (snap.hasData) ...snap.data!.map((a) => Card(child: ListTile(
        leading: const Icon(Icons.pets), title: Text('${a['name']}'),
        subtitle: Text('टैग: ${a['tag'] ?? '-'}  •  वजन: ${a['weight']} किलो'))))
    ]),
  );
}

class MilkPage extends StatefulWidget {
  final VoidCallback onRefresh;
  const MilkPage({super.key, required this.onRefresh});
  @override
  State<MilkPage> createState() => _MilkPageState();
}
class _MilkPageState extends State<MilkPage> {
  int? animalId; String session = 'सुबह';
  final litres = TextEditingController();
  Future<void> save() async {
    final v = double.tryParse(litres.text);
    if (animalId == null || v == null) return;
    await DairyDb.instance.addMilk(animalId!, session, v);
    litres.clear(); setState(() {}); widget.onRefresh();
  }
  @override
  Widget build(BuildContext context) => FutureBuilder(
    future: Future.wait([DairyDb.instance.animals(), DairyDb.instance.milkToday()]),
    builder: (context, snap) {
      if (!snap.hasData) return const Center(child: CircularProgressIndicator());
      final animals = snap.data![0] as List<Map<String, Object?>>;
      final entries = snap.data![1] as List<Map<String, Object?>>;
      return ListView(padding: const EdgeInsets.all(16), children: [
        _pageHeading('दूध का रिकॉर्ड', 'सुबह और शाम का दूध अलग-अलग दर्ज करें', Icons.water_drop_rounded),
        if (animals.isEmpty) const Text('पहले भैंस टैब में भैंस जोड़ें।'),
        DropdownButton<int>(
          isExpanded: true, value: animals.any((a) => a['id'] == animalId) ? animalId : null,
          hint: const Text('भैंस चुनें'),
          items: animals.map((a) => DropdownMenuItem(value: a['id'] as int, child: Text('${a['name']}'))).toList(),
          onChanged: (v) => setState(() => animalId = v),
        ),
        DropdownButton<String>(value: session, isExpanded: true,
          items: const [DropdownMenuItem(value: 'सुबह', child: Text('सुबह')), DropdownMenuItem(value: 'शाम', child: Text('शाम'))],
          onChanged: (v) => setState(() => session = v ?? 'सुबह')),
        TextField(controller: litres, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'दूध (लीटर)')),
        FilledButton(onPressed: save, child: const Text('दूध सेव करें')),
        const Divider(),
        const Text('आज की एंट्री', style: TextStyle(fontWeight: FontWeight.bold)),
        ...entries.map((e) => ListTile(title: Text('${e['animal_name'] ?? 'भैंस'} • ${e['session']}'), trailing: Text('${e['litres']} लीटर')))
      ]);
    });
}

class FeedPage extends StatefulWidget {
  final VoidCallback onRefresh;
  const FeedPage({super.key, required this.onRefresh});
  @override
  State<FeedPage> createState() => _FeedPageState();
}
class _FeedPageState extends State<FeedPage> {
  int? animalId; String item = 'सरसों की खल';
  final kg = TextEditingController();
  final options = const ['सरसों की खल', 'गेहूँ का चोकर', 'गन्ने की अगोली', 'सूखा भूसा', 'हरा चारा', 'मिनरल मिक्सचर'];
  Future<void> save() async {
    final v = double.tryParse(kg.text);
    if (animalId == null || v == null) return;
    await DairyDb.instance.addFeed(animalId!, item, v);
    kg.clear(); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('खुराक का रिकॉर्ड सेव हो गया')));
  }
  @override
  Widget build(BuildContext context) => FutureBuilder(
    future: DairyDb.instance.animals(),
    builder: (context, snap) {
      if (!snap.hasData) return const Center(child: CircularProgressIndicator());
      final animals = snap.data!;
      return ListView(padding: const EdgeInsets.all(16), children: [
        _pageHeading('पशुओं की खुराक', 'हर पशु को दी गई मात्रा का रिकॉर्ड रखें', Icons.grass_rounded),
        DropdownButton<int>(isExpanded: true, value: animals.any((a) => a['id'] == animalId) ? animalId : null,
          hint: const Text('भैंस चुनें'), items: animals.map((a) => DropdownMenuItem(value: a['id'] as int, child: Text('${a['name']}'))).toList(),
          onChanged: (v) => setState(() => animalId = v)),
        DropdownButton<String>(isExpanded: true, value: item, items: options.map((o) => DropdownMenuItem(value: o, child: Text(o))).toList(), onChanged: (v) => setState(() => item = v ?? options.first)),
        TextField(controller: kg, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'मात्रा (किलो / ग्राम को किलो में लिखें)')),
        FilledButton(onPressed: save, child: const Text('खुराक सेव करें')),
      ]);
    });
}

class RationPage extends StatelessWidget {
  const RationPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    _pageHeading('खुराक सलाह', 'सुरक्षित आहार के लिए जरूरी बातें', Icons.calculate_rounded),
    SizedBox(height: 8),
    Text('यह भाग अभी प्रारंभिक रूप में है। केवल वजन और दूध देखकर सटीक राशन तय नहीं किया जा सकता। हरे चारे, सूखे चारे, खल/चोकर की गुणवत्ता, शरीर की हालत और गर्भावस्था की जानकारी जरूरी है।'),
    SizedBox(height: 12),
    Card(child: Padding(padding: EdgeInsets.all(14), child: Text('सुरक्षा: ऐप की सलाह को पशु चिकित्सक या पशु पोषण विशेषज्ञ से मिलाकर ही लागू करें। खुराक अचानक न बदलें। फफूंद लगा चारा न दें और साफ पानी हमेशा रखें।'))),
    Text('अगले संस्करण में दूध, वजन और चारे की किस्म के आधार पर राशन कैलकुलेटर जोड़ा जाएगा।')
  ]);
}

Widget _pageHeading(String title, String subtitle, IconData icon) => Padding(
  padding: const EdgeInsets.only(bottom: 16),
  child: Row(children: [
    Container(width: 48, height: 48, decoration: BoxDecoration(color: const Color(0xFFDDF2E6), borderRadius: BorderRadius.circular(15)), child: Icon(icon, color: const Color(0xFF167A55), size: 25)),
    const SizedBox(width: 12),
    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: Color(0xFF183B2B))),
      const SizedBox(height: 2),
      Text(subtitle, style: const TextStyle(fontSize: 12, color: Color(0xFF718078))),
    ])),
  ]),
);
