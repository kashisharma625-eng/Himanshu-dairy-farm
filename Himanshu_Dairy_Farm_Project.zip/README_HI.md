# Himanshu Dairy Farm — Android APK बनाने के लिए

इस ZIP में ऐप का Flutter source code और GitHub Actions build workflow है।
इसमें पहले से Android/SDK build output शामिल नहीं है; GitHub का cloud runner Android project files बनाकर APK तैयार करेगा।

## मोबाइल से APK बनाने के स्टेप

1. इस ZIP को डाउनलोड करके extract करें।
2. Chrome में https://github.com खोलें और sign in करें।
3. नया repository बनाएं; नाम रखें `himanshu-dairy-farm` और उसे Public या Private चुनें।
4. Extract किए हुए फ़ोल्डर की सभी फाइलें repository में upload करें। `.github/workflows/android-apk.yml` भी upload होना चाहिए।
5. Repository में **Actions** टैब खोलें।
6. **Build Android APK** workflow चुनें और **Run workflow** दबाएं।
7. Build सफल होने पर उसी run के नीचे **Artifacts** में `himanshu-dairy-farm-apk` मिलेगा। उसे डाउनलोड करके ZIP खोलें; अंदर `app-release.apk` होगी।
8. APK पर टैप करके install करें। Android पूछे तो Chrome/Files को उस स्रोत से install करने की अनुमति दें।

## ऐप में موجود फीचर
- डैशबोर्ड: कुल पशु और आज का दूध
- पशु जोड़ना: नाम, टैग और वजन
- दूध रिकॉर्ड: सुबह/शाम की एंट्री
- खुराक रिकॉर्ड: पशु के अनुसार चारा/खल आदि
- प्रारंभिक खुराक सलाह

## ध्यान दें
- डेटा फोन के ऐप के स्थानीय SQLite डेटाबेस में सेव होता है।
- ऐप को पहली बार install करने के बाद रिकॉर्ड उसी फोन पर रहेगा; ऐप uninstall या app data clear करने पर डेटा मिट सकता है।
- यह ZIP build workflow तैयार करती है; APK अभी इस बातचीत में build या फोन पर test नहीं हुई है।
